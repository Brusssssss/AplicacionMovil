import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ExploreContainerComponentModule } from '../explore-container/explore-container.module';
import { IonicModule } from '@ionic/angular';
import { QRCodeModule } from 'angularx-qrcode';
import { RegistroasistenciaPageRoutingModule } from './registroasistencia-routing.module';
import { RegistroasistenciaPage } from './registroasistencia.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    QRCodeModule,
    ExploreContainerComponentModule,
    RegistroasistenciaPageRoutingModule
  ],
  declarations: [RegistroasistenciaPage]
})
export class RegistroasistenciaPageModule {}
