import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { QRCodeModule } from 'angularx-qrcode';
import { RegistroasistenciaPage } from './registroasistencia.page';

const routes: Routes = [
  {
    path: '',
    component: RegistroasistenciaPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes), QRCodeModule],
  exports: [RouterModule],
})
export class RegistroasistenciaPageRoutingModule {}
