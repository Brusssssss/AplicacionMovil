import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ApiusersService } from 'src/app/pages/services/apiusers.service';
import { ActivatedRoute } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { IClases } from 'src/interfaces/RegistroClases';
import { ApicrudService } from 'src/app/services/apicrud.service';


@Component({
  selector: 'app-registroasistencia',
  templateUrl: './registroasistencia.page.html',
  styleUrls: ['./registroasistencia.page.scss'],
})
export class RegistroasistenciaPage implements OnInit {
  
  rut:any;
  email:any;
  qrdata:string;
  
  clases: IClases[]=[];
  claseseleccionada: IClases | null = null;
  constructor(private apicrud: ApicrudService, private apiuser:ApiusersService, private router: Router) {this.qrdata = '';
    this.rut = sessionStorage.getItem('rut');
    this.email = sessionStorage.getItem('email');
  }
  
  
  ngOnInit(){
    this.apiuser.getClases().subscribe(data => {
      this.clases = data;
    });
  }

  seleccionarclase(clase: IClases){
    console.log("---")
    this.claseseleccionada = clase;
    this.generarQr()
  }

  generarQr(){
    if (this.claseseleccionada) {
      const {profesor, ramo, sala, seccion, fecha} = this.claseseleccionada;
      this.qrdata = `${profesor} ${ramo} ${sala} ${seccion} ${fecha} ${this.rut} ${this.email}`;

      this.router.navigate(['/qr'],{
        queryParams: {qrdata: this.qrdata}
      });
    }
  }
  
  
}
