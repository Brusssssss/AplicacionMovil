import { ComponentFixture, TestBed } from '@angular/core/testing';
import { IonicModule } from '@ionic/angular';

import { ExploreContainerComponentModule } from '../explore-container/explore-container.module';

import { RegistroasistenciaPage } from './registroasistencia.page';

describe('RegistroasistenciaPage', () => {
  let component: RegistroasistenciaPage;
  let fixture: ComponentFixture<RegistroasistenciaPage>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [RegistroasistenciaPage],
      imports: [IonicModule.forRoot(), ExploreContainerComponentModule]
    }).compileComponents();

    fixture = TestBed.createComponent(RegistroasistenciaPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
