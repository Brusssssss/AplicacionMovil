import { Component, OnInit } from '@angular/core';
import { ApiusersService } from '../services/apiusers.service';
import { FormBuilder, FormGroup } from '@angular/forms';

@Component({
  selector: 'app-perfil',
  templateUrl: './perfil.page.html',
  styleUrls: ['./perfil.page.scss'],
})
export class PerfilPage implements OnInit {

  usuarios: any[] = [];
  loggedUser: any;
  editForm: FormGroup; // Propiedad editForm declarada

  constructor(private apiuser: ApiusersService, private formBuilder: FormBuilder) {
    // Inicializa editForm con un nuevo FormGroup vacío
    this.editForm = this.formBuilder.group({
      rut: [''],
      email: [''],
      password: [''],
      fechanac: ['']
    });
  }

  ngOnInit() {
    const userData = sessionStorage.getItem('loggedUser');
    if (userData) {
      this.loggedUser = JSON.parse(userData);

      // Llenar el formulario con los valores del usuario logueado
      this.editForm.patchValue({
        rut: this.loggedUser.rut,
        email: this.loggedUser.email,
        password: this.loggedUser.password,
        fechanac: this.loggedUser.fechanac
      });
    }
  }

  // Método para obtener los usuarios (si es necesario)
  Usuarios() {
    this.apiuser.getUsers().subscribe(datos => this.usuarios = datos);
  }

  // Método para cambiar la foto del usuario
  cambiarfoto(event: any) {
    const file = event.target.files[0];
    if (file) {
      const reader = new FileReader();
      // Aquí puedes agregar la lógica para manejar la carga de la foto
    }
  }

  // Método para actualizar el usuario
  actualizarUsuario(): void {
    if (this.editForm && this.editForm.valid) {
      this.apiuser.actualizarUsuario(this.loggedUser.id, this.editForm.value)
        .subscribe(
          (response: any) => {
            console.log('Usuario actualizado:', response);
            // Aquí puedes agregar lógica adicional, como redirigir o mostrar un mensaje de éxito
          },
          (error: any) => {
            console.error('Error al actualizar el usuario:', error);
            // Manejo de errores
          }
        );
    } else {
      console.log('Formulario inválido');
    }
  }
}
