import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable} from 'rxjs';
import { environment } from 'src/environments/environment';
import { IClases,IClase } from 'src/interfaces/RegistroClases';
import { Users } from 'src/interfaces/users';
@Injectable({
  providedIn: 'root'
})
export class ApicrudService {
  constructor(private httpclient: HttpClient) { }

  getClases():Observable<IClases[]>{
    return this.httpclient.get<IClases[]>(`${environment.apiUrl}/registroclase`);
  }

  postClases(newClase: IClase):Observable<IClase>{
    return this.httpclient.post<IClase>(`${environment.apiUrl}/registroclase`,newClase);
  }

  getClaseID(id:number):Observable<IClases>{
    return this.httpclient.get<IClases>(`${environment.apiUrl}/registroclase/?id=${id}`);
  }

  putClases(clase:any):Observable<IClases>{
    return this.httpclient.put<IClases>(`${environment.apiUrl}/registroclase/${clase.id}`, clase);
  }

  deleteCurso(clase:any):Observable<IClases>{
    return this.httpclient.delete<IClases>(`${environment.apiUrl}/registroclase/${clase.id}`);
  }
}