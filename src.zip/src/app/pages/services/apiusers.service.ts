import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ApiusersService{

  apiUrl='http://localhost:3000/registroclase';
  apiUrl1='http://localhost:3000/usuarios';
  constructor(private http: HttpClient) {}
  
  getClases():Observable<any>{
    return this.http.get<any>(this.apiUrl);
  }
  getUsers():Observable<any>{
    return this.http.get<any>(this.apiUrl1);
  }
  
  logout() {
    // Eliminar el usuario logueado de sessionStorage
    sessionStorage.removeItem('loggedUser');
  }

  cambiarfoto(username:string){
    this.http.get<any>(this.apiUrl1 + '?username='+username).subscribe(usuarios => {
      if(usuarios.length > 0){
        const usuario = usuarios[0];
      }
    });
  }
  actualizarUsuario(id: number, userData: any): Observable<any> {
    return this.http.put(`${this.apiUrl}/${id}`, userData);
  }
}
