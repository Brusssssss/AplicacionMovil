import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
@Component({
  selector: 'app-qr',
  templateUrl: './qr.page.html',
  styleUrls: ['./qr.page.scss'],
})
export class QrPage implements OnInit {
  qrdata:string = '';
  constructor(private route:ActivatedRoute) { }
  
  ngOnInit() {
    // Obtener los datos pasados desde la página anterior
    this.route.queryParams.subscribe(params => {
      if (params['qrdata']) {
        this.qrdata = params['qrdata'];
      }
    });
  }

}
