import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AlertController } from '@ionic/angular';
@Component({
  selector: 'app-justificacion',
  templateUrl: './justificacion.page.html',
  styleUrls: ['./justificacion.page.scss'],
})
export class JustificacionPage implements OnInit {

  constructor(private alertcontroller: AlertController, private router: Router) { }

  ngOnInit() {
  }
  async enviar() {
    const alert = await this.alertcontroller.create({
      header: 'Justificación enviada correctamente!!',
      mode: 'ios',
      cssClass: 'alertHeader',
      buttons: [
        {
          text: 'OK',
          role: 'confirm',
          handler: () => {
            console.log('Justificación enviada correctamente!!');
            this.router.navigate(['/inicio']);
          },
        },
      ],
    });

    await alert.present();

  }
  subirArchivo(event: any) {
    const file = event.target.files[0];
    if (file) {
      const reader = new FileReader();
      this.enviar();
    }
  }


}
