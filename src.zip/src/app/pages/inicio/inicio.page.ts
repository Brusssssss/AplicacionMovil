import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { Router } from '@angular/router';
import { MenuController } from '@ionic/angular';
import { AlertController } from '@ionic/angular';
import Swiper from 'swiper';

// Configura los módulos que vas a usar
@Component({
  selector: 'app-inicio',
  templateUrl: './inicio.page.html',
  styleUrls: ['./inicio.page.scss'],
})
export class InicioPage  {
  @ViewChild('swiper')
  swiperRef: ElementRef | undefined;
  swiper?: Swiper;

  images = [
    'https://intecorecoleta.cl/wp-content/uploads/2022/08/programacion-2-e1551291144973.jpg',
  ];

  constructor(private router: Router, private menu: MenuController) { }
  

  
  swiperReady(){
    this.swiper = this.swiperRef?.nativeElement.swiper;
  }

  goNext(){
    this.swiper?.slideNext();
  }
  goPrev(){
    this.swiper?.slidePrev();
  }

  swiperSlideChanged(e:any){
    console.log('changed: ', e)
  }
  gologin(){
    this.router.navigate(['/login'])
  }
  goregistro(){
    this.router.navigate(['/registro'])
  }
  mostrarMenu(){
    this.menu.open('first')
  }

}
