import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, ObservableLike } from 'rxjs';
import { environment } from 'src/environments/environment';


@Injectable({
  providedIn: 'root'
})
export class ApicrudService {
  getClases() {
    throw new Error('Method not implemented.');
  }

  constructor(private httpclient: HttpClient) { }


}