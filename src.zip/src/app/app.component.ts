import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService } from './pages/services/auth.service';
import { register } from 'swiper/element/bundle';


register();

interface Opciones{
  icon: string;
  name: string; 
  redirecTo?: string; 
  action?: string;
}

@Component({
  selector: 'app-root',
  templateUrl: 'app.component.html',
  styleUrls: ['app.component.scss'],
})
export class AppComponent {
  opciones: Opciones[]=[ 
    {
      icon:'happy-outline',
      name:'Perfil',
      redirecTo: '/perfil',
    },
    {
      icon:'qr-code-outline',
      name:'Registro de Asistencia',
      redirecTo: '/registroasistencia',
    },
    {
      icon:'document-attach-outline',
      name:'Justificación de Inasistencia',
      redirecTo: '/justificacion',
    },
    {
      icon:'log-out-outline',
      name:'Cerrar Sesion',
      action: 'logout',
    },
  ]
  constructor(private authService: AuthService, private router: Router) {}
  onSelect(option: any) {
    if (option.action === 'logout') {
      this.onLogout(); // Llama al método de logout si la acción es "logout"
    } else {
      // Redirigir a la página correspondiente si no es logout
      this.router.navigate([option.redirecTo]);
    }
  }
  
  onLogout() {
    this.authService.logout();  // Eliminar la sesión desde sessionStorage
    this.router.navigate(['/login']);
    sessionStorage.removeItem('username'); 
    sessionStorage.removeItem('apellido');  // Redirigir al login
  }
}
