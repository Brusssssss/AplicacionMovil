export interface Users{
    id:number;
    username:string;
    rut:string;
    fechanac:string;
    apellido: string;
    email:string;
    password:string;
    isactive: boolean;
}

export interface UserNuevo{
    username:string;
    rut:string;
    fechanac:string;
    apellido: string;
    email:string;
    password:string;
    isactive: boolean;
}