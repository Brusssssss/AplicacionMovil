export interface IClases{
    id:number;
    profesor:string;
    sala:string;
    seccion:string;
    ramo:string;
    fecha:string;
    imagen:string;

}

export interface IClase{
    profesor:string;
    sala:string;
    seccion:string;
    ramo:string;
    fecha:string;
    imagen:string;
}